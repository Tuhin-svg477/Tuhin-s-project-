const portfolios = [];

const createPortfolio = (req, res) => {
    const portfolio = { id: Date.now(), ...req.body };
    portfolios.push(portfolio);
    res.json(portfolio);
};

const getPortfolios = (req, res) => {
    res.json(portfolios);
};

const updatePortfolio = (req, res) => {
    const index = portfolios.findIndex(p => p.id == req.params.id);
    if (index > -1) {
        portfolios[index] = { ...portfolios[index], ...req.body };
        res.json(portfolios[index]);
    } else {
        res.status(404).send('Portfolio not found');
    }
};

const deletePortfolio = (req, res) => {
    const index = portfolios.findIndex(p => p.id == req.params.id);
    if (index > -1) {
        portfolios.splice(index, 1);
        res.send('Portfolio deleted');
    } else {
        res.status(404).send('Portfolio not found');
    }
};

module.exports = { createPortfolio, getPortfolios, updatePortfolio, deletePortfolio };
