const express = require('express');
const dotenv = require('dotenv');
const userRoutes = require('./routes/userRoutes');
const portfolioRoutes = require('./routes/portfolioRoutes');

dotenv.config();
const app = express();

app.use(express.json());

app.use('/api/users', userRoutes);
app.use('/api/portfolios', portfolioRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
