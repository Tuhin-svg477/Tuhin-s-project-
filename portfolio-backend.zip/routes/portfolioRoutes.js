const express = require('express');
const { createPortfolio, getPortfolios, updatePortfolio, deletePortfolio } = require('../controllers/portfolioController');
const auth = require('../middleware/auth');
const router = express.Router();

router.post('/', auth, createPortfolio);
router.get('/', auth, getPortfolios);
router.put('/:id', auth, updatePortfolio);
router.delete('/:id', auth, deletePortfolio);

module.exports = router;
