// Placeholder for database model.
