const express = require('express');
const { helloWorld, getToken, postResponse } = require('../controllers/apiController');
const router = express.Router();

router.get('/', helloWorld);
router.get('/token', getToken);
router.post('/post', postResponse);

module.exports = router;
