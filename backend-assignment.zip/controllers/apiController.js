const generateToken = require('../utils/generateToken');

const helloWorld = (req, res) => {
    res.send('Hello World');
};

const getToken = (req, res) => {
    const token = generateToken({ id: 1, name: 'User' });
    res.json({ token });
};

const postResponse = (req, res) => {
    res.send('I am post body');
};

module.exports = { helloWorld, getToken, postResponse };
