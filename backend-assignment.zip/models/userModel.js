// Placeholder model file (not used in basic API)
