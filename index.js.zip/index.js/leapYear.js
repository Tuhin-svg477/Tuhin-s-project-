
function isLeapYear(year) {
    // A year is a leap year if it is divisible by 4 but not divisible by 100,
    // unless it is also divisible by 400.
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}


console.log(isLeapYear(2024)); // Output: true
console.log(isLeapYear(1900)); // Output: false
console.log(isLeapYear(2000)); // Output: true
console.log(isLeapYear(2023)); // Output: false