
function findAverage(numbers) {
    // Check if the array is empty
    if (numbers.length === 0) return 0;

    // Calculate the sum and divide by the length of the array
    const sum = numbers.reduce((acc, num) => acc + num, 0);
    return sum / numbers.length;
}

console.log(findAverage([1, 2, 3, 4, 5])); // Output: 3
console.log(findAverage([]));              // Output: 0