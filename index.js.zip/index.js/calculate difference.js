/* Write a function named calculate difference that takes two argument and returns the difference between the first and second argument  */

const a = Number(prompt("Enter the value of A"))
const b = Number(prompt("Enter the value of B"))

console.log(`${a}-${b}=${a-b}`);