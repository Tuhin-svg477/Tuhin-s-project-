
function lowercaseFirstLetter(str) {
    // Check if the string is not empty
    if (str.length === 0) return str;

    // Convert the first letter to lowercase and concatenate with the rest
    return str[0].toLowerCase() + str.slice(1);
}


console.log(lowercaseFirstLetter("Hello")); // Output: "hello"
console.log(lowercaseFirstLetter("WORLD")); // Output: "wORLD"