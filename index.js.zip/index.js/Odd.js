/* Write a function that named Odd that takes one argument and returns true if the number is Odd,add false if it is not*/

function Odd(number) {
    // Returns true if the number is odd, false if it is not
    return number % 2 !== 0;
}

console.log(Odd(3)); // Output: true
console.log(Odd(4)); // Output: false