/*  */

function sortArrayDescending(numbers) {
    // Use the sort method to arrange numbers in descending order
    return numbers.sort((a, b) => b - a);
}

console.log(sortArrayDescending([5, 2, 8, 1, 3])); // Output: [8, 5, 3, 2, 1]