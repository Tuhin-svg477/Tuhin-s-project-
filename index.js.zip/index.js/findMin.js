/* Write a function that named findMin that takes array of numbers and returns the smallest number from the array*/

function findMin(numbers) {
    // Check if the array is empty
    if (numbers.length === 0) {
        throw new Error("Array is empty");
    }

    // Use Math.min with spread syntax to find the smallest number
    return Math.min(...numbers);
}

console.log(findMin([3, 5, 1, 8, 2])); // Output: 1
console.log(findMin([-10, 0, 5, 7]));  // Output: -10