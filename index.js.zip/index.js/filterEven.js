/* Write a function that named filterEvenNumbers that takes an array of numbers and returns a new array containing only the EvenNumbers*/

function filterEvenNumbers(numbers) {
    // Use the filter method to get only even numbers
    return numbers.filter(number => number % 2 === 0);
}

console.log(filterEvenNumbers([1, 2, 3, 4, 5, 6])); // Output: [2, 4, 6]
console.log(filterEvenNumbers([7, 9, 13, 15]));    // Output: []